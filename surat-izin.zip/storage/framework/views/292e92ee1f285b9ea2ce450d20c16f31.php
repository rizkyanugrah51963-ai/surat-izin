<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0d1b2a, #1b263b, #415a77);
        }

        .register-container {
            width: 400px;
            background: rgba(255, 255, 255, 0.07);
            padding: 35px;
            border-radius: 14px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(8px);
        }

        h2 {
            text-align: center;
            color: #fff;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .input-group {
            margin-bottom: 18px;
        }

        .input-group label {
            color: #ddd;
            font-size: 14px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 14px;
            margin-top: 5px;
            border-radius: 10px;
            border: none;
            outline: none;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            font-size: 15px;
        }

        .input-group input:focus {
            background: rgba(255, 255, 255, 0.35);
        }

        .btn-register {
            width: 100%;
            padding: 12px;
            background: #1e90ff;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-register:hover {
            background: #1c7ed6;
        }

        .error-message {
            background: rgba(255, 0, 0, 0.25);
            padding: 10px;
            color: #fff;
            margin-bottom: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .link-login {
            text-align: center;
            margin-top: 10px;
        }

        .link-login a {
            color: #1e90ff;
            text-decoration: none;
        }

        .link-login a:hover {
            color: #1c7ed6;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <h2>Register Admin</h2>

        <?php if($errors->any()): ?>
            <div class="error-message">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="error-message" style="background: rgba(0,255,0,0.25); color:#fff;"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.register.submit')); ?>">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <label>Nama</label>
                <input type="text" name="name" placeholder="Masukkan nama" required>
            </div>
            <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Masukkan email admin" required>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Masukkan password" required>
            </div>
            <div class="input-group">
                <label>Konfirmasi Password</label>
                <input type="password" name="password_confirmation" placeholder="Konfirmasi password" required>
            </div>
            <button type="submit" class="btn-register">Register</button>
        </form>

        <div class="link-login">
            Sudah punya akun? <a href="<?php echo e(route('admin.login')); ?>">Login Admin</a>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\laragon\www\surat-izin\resources\views/admin/register.blade.php ENDPATH**/ ?>